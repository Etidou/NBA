import $ from 'jquery';
import TeamsWest from './teamsWest';



export default class SecondBackground 
{
    constructor () {
        console.log("init");
    }
}
 new TeamsWest();