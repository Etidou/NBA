import $ from 'jquery';
import TeamsEast from './teamsEast';



export default class SecondBackground 
{
    constructor () {
        console.log("init");
    }
}
 new TeamsEast();